This medium contains my bachelor thesis and it's LaTeX source code. See https://github.com/davidmasek/Algorithms-for-video-analysis-of-customer-behavior-in-front-of-retail-store for suplementary materials.

The structure is following.

- readme.txt - the file with CD contents description
- src - the directory of LaTeX source codes of the thesis
- thesis.pdf - the thesis text in PDF format

